import 'package:pocutom/passageiro.dart';

class Funcionario extends Passageiro {
  int? registro;

  Funcionario(cpf, nome, end, tel) : super(cpf, nome, end, tel);
}
