import 'package:pocutom/passageiro.dart';

class Cliente extends Passageiro {
  Cliente(cpf, nome, end, tel) : super(cpf, nome, end, tel);
}
